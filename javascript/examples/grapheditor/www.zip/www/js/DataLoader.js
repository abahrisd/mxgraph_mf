/**
 * Load and set privilege
 */
function DataLoader(editorUi, styleUrl, cellsUrl)
{
    this.editorUi = editorUi;
    this.graph = this.editorUi.editor.graph;
    this.parent = this.graph.getDefaultParent();
    this.globalUsersCellX = 40;
    this.globalUsersCellY = 40;

    this.stylesheet = '';
    this.linkTypes = '';
    this.objectTypes = '';

    this.init(styleUrl,cellsUrl);
};

/**
 * Init setting privilege
 */
DataLoader.prototype.init = function(styleUrl,cellsUrl) {

    //this.loadStylesheetDoc(styleUrl);

    //loading from JSON OR(!) from XML

    this.loadJSONData(cellsUrl);
    //this.loadXMLData('fixtures/testnode.xml');
};

/**
 * Load object type data, like stylesheet, linkTypes, objectTypes and store it in local variables
 */
DataLoader.prototype.loadTypeData = function(url) {

    var req = mxUtils.load(url);
    var responseData = JSON.parse(req.getText());

    if (responseData.stylesheet){
        this.stylesheet = responseData.stylesheet;
    }

    //TODO store this data
    if (responseData.linkTypes){
        this.linkTypes = responseData.linkTypes;
    }

    //TODO store this data
    if (responseData.objectTypes){
        this.objectTypes = responseData.objectTypes;
    }

};

/**
 * Set styleseet from this.stylesheet
 */
DataLoader.prototype.setStylesheet = function(url) {

    var graph = this.graph;

    if (this.stylesheet){
        var stylesheet = this.stylesheet;
        var doc = mxUtils.parseXml(stylesheet);
        var root = doc.documentElement;
        var dec = new mxCodec(root.ownerDocument);
        var nodstyle = dec.decode(root, graph.stylesheet);
    }
};

/**
 * Load stylesheet.xml from server and set it to graph
 */
DataLoader.prototype.loadJSONData = function(url){
    
    var _this = this;
    var graph = this.graph;

    var onload = function(req){
        try{
            var responseData = JSON.parse(req.getText());

            if (responseData !== undefined){

                //load xml there
                if (responseData.type){
                    //TODO dynamicaly create url based on type.uuid

                    _this.loadTypeData('http://217.74.43.104:8080/sd/services/rest/get/presentType$98301?accessKey=2c26e34c-e9e8-4120-9f76-c4661bb748ae');

                    _this.setStylesheet();

                }

                //draw graph
                if (responseData.relevantData) {
                    var objects4Diag = JSON.parse(responseData.relevantData);
                    if (objects4Diag.objects){
                        objects4Diag.objects.forEach(function(el){
                            _this.createCellFromUserObject(el);
                        })
                    }

                    if (objects4Diag.links){
                        objects4Diag.links.forEach(function(el){
                            //TODO create structure for fast search cell by _metaClass
                            var source, target;

                            graph.getModel().getDescendants(graph.getDefaultParent()).forEach(function(cell){

                                if (cell && cell.getValue()){

                                    //console.log("_metaClass", cell.getValue().getAttribute('_metaClass'));
                                    if (cell.getValue().getAttribute('_UUID') == el.source) {
                                        source = cell;
                                    }

                                    if (cell.getValue().getAttribute('_UUID') == el.target) {
                                        target = cell;
                                    }
                                }
                            });

                            if (source && target){
                                graph.insertEdge(graph.getDefaultParent(), null, null, source, target);
                            }

                        });
                    }

                    //arrange organic
                    //TODO call this from menu items
                    var layout = new mxHierarchicalLayout(graph, mxConstants.DIRECTION_NORTH);
                    _this.editorUi.executeLayout(function()
                    {
                        var selectionCells = graph.getSelectionCells();
                        layout.execute(graph.getDefaultParent(), selectionCells.length == 0 ? null : selectionCells);
                    }, true);
                }
            }

        } catch (e){
            console.log('Error while parsing JSON ',e.stack);
        }
    };

    var onerror = function(req){
        mxUtils.alert('Error while getting diagram from server');
    };

    new mxXmlRequest(url, 'key=value', 'GET').send(onload, onerror);
}


/**
 * Load graph in xml from server
 */
DataLoader.prototype.loadXMLData = function(url){

    var _this = this;
    var editor = this.editorUi.editor;

    var onload = function(req){
        try{
            var xml = req.getText();

            var doc = mxUtils.parseXml(xml);
            editor.setGraphXml(doc.documentElement);
            editor.setModified(false);

            //export xml node, for debug only
            var encoder = new mxCodec();
            var styleEncoder = mxCodecRegistry.getCodec('mxStylesheet');
            var node = styleEncoder.encode(encoder,_this.graph.getStylesheet());

            //TODO send node on server

            //debug stuff
            //console.log(new mxCodec().encode(mxCodecRegistry.getCodec('mxStylesheet'),EditUI.editor.graph.getStylesheet()))


        } catch (e){
            console.log('Error while parsing JSON ',e.stack);
        }
    };

    var onerror = function(req){
        mxUtils.alert('Error while getting diagram from server');
    };

    new mxXmlRequest(url, 'key=value').send(onload, onerror);
}


/**
 * Create vetecies from object
 * obj decoded from JSON
 * return void
 */
DataLoader.prototype.createCellFromUserObject = function(obj){

    var doc = mxUtils.createXmlDocument();
    var node = doc.createElement('UserNode');
    var graph = this.graph;
    var parent = this.parent;

    var width = '';
    var height = '';
    var titleLength = obj.title?obj.title.length:0;

    var globalUsersCellX = this.globalUsersCellX;
    var globalUsersCellY = this.globalUsersCellY;

    //set title
    node.setAttribute('label', obj.title?obj.title:'');

    //set attributes, except title
    for (var key in obj) {

        //TODO refactor it!
        if (key === 'metaClass') {
            node.setAttribute('_metaClass', obj[key]);
        } else if (key === 'UUID') {
            node.setAttribute('_UUID', obj[key]);
        } else {
            node.setAttribute(key, obj[key]);
        }
    }

    var style = '';
    if (obj.metaClass){
        switch(obj.metaClass){
            case 'ae$bpstep':
                style = 'step';
                break;
        }
    }

    //adjust cell size by label length
    if (titleLength <= 40){
        width = 130;
        height = 50;
    } else if (titleLength <= 80){
        width = 140;
        height = 80;
    } else if (titleLength <= 120){
        width = 180;
        height = 80;
    } else if (titleLength <= 160){
        width = 220;
        height = 100;
    } else if (titleLength <= 200){
        width = 220;
        height = 110;
    } else {
        width = 265;
        height = 115;
    }

    //graph.insertVertex(parent, null, node, globalUsersCellX, globalUsersCellY, null, null, style);
    graph.insertVertex(parent, null, node, globalUsersCellX, globalUsersCellY, width, height, style);
    this.globalUsersCellX += 10;
    this.globalUsersCellY += 10;
}

/**
 * Load stylesheet from server and set it to graph, from server shold came XML!
 */
DataLoader.prototype.loadStylesheetDoc = function(url){

    var _this = this;
    var req = mxUtils.load(url);
    var root = req.getDocumentElement();
    var dec = new mxCodec(root.ownerDocument);
    dec.decode(root, _this.graph.stylesheet);

}
/**
 * Export xml node
 */
DataLoader.prototype.exportXMLNode = function(){

    //export xml node, for debug only
    var graph = this.graph;
    var encoder = new mxCodec();
    var styleEncoder = mxCodecRegistry.getCodec('mxStylesheet');
    var node = styleEncoder.encode(encoder,graph.getStylesheet());

    //console.log('export node',node);
    //console.log('export node xml',mxUtils.getXml(node));

    //TODO send node on server
    //debug stuff
    //console.log(new mxCodec().encode(mxCodecRegistry.getCodec('mxStylesheet'),EditUI.editor.graph.getStylesheet()))

}
