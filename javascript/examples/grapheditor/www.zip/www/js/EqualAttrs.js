/**
 * Listen changes of cells, and make equal attributes in cells with same paramName
 */
function EqualAttrs(editorUi, paramName)
{
    this.editorUi = editorUi;
    this.graph = this.editorUi.editor.graph;
    this.paramName = paramName;

    this.globalUsersCellX = 40;
    this.globalUsersCellY = 40;
    this.parent = this.graph.getDefaultParent();

    this.init();
};

/**
 * Init listen changes
 */
EqualAttrs.prototype.init = function() {
    var graph = this.graph;
    var _this = this;

    graph.getModel().addListener(mxEvent.CHANGE, function(sender, evt){
        var changes = evt.getProperty('edit').changes;

        //param to search equal elements
        var param = _this.paramName;

        changes.forEach(function(el){

            //if changes in vertex with UUID
            if (el.cell && el.cell.isVertex() && el.cell.getValue() && el.cell.getValue().getAttribute && el.cell.getValue().getAttribute(param)){
                var cell = el.cell;

                //check is exists dublicates elements with same UUID
                var cellsSameUUID = _this.findEqualCells(cell, param);

                //copy attrs from cell to each cellsSameUUID
                if (cellsSameUUID.length > 0) {
                    _this.setAttributesEqual(cell, cellsSameUUID)
                }
            }
        });
    });

    //FIXME It's wrong to load cells there
    this.getCellsByURL('fixtures/testdata.json');

    //this.setRights();
        
};

/**
 * Find cells with same paramName as in provided cell
 * cell - provided cell
 * return Array of cells
 */
EqualAttrs.prototype.findEqualCells = function(cell, paramName) {
    var cells = [];
    var graph = this.graph;
    var UUID = cell.getValue().getAttribute(paramName);
    var cellId = cell.getId();

    graph.getModel().getDescendants(graph.getDefaultParent()).forEach(function(el){
        if (el.getValue() && el.getValue().getAttribute && el.getValue().getAttribute(paramName) && el.getValue().getAttribute(paramName) === UUID && cellId != el.getId()){
            cells.push(el)
        }
    });

    return cells;
};

/**
 * Set attributes from cell equal to all cells in cellsSameUUID
 * cell - source cell
 * cellsToUpdate - array of cells to make attributes equal sourse cell
 * return boolean
 */
EqualAttrs.prototype.setAttributesEqual = function(cell, cellsToUpdate){

    var graph = this.graph;
    graph.getModel().beginUpdate();
    try
    {
        cellsToUpdate.forEach(function(el){

            for (var i = 0, atts = cell.getValue().attributes, n = atts.length; i < n; i++){
                el.getValue().setAttribute(atts[i].nodeName, atts[i].nodeValue);
            }
        });

    }
    finally
    {
        graph.getModel().endUpdate();
    }
}


/**
 * Create vetecies from object
 * obj decoded from JSON
 * return void
 */
EqualAttrs.prototype.createCellFromUserObject = function(obj){

    var doc = mxUtils.createXmlDocument();
    var node = doc.createElement('UserNode');
    var graph = this.graph;
    var parent = this.parent;
    var globalUsersCellX = this.globalUsersCellX;
    var globalUsersCellY = this.globalUsersCellY;

    //set title
    node.setAttribute('label', obj.title?obj.title:'UserLabel');

    //set attributes, except title
    for (var key in obj) {
        //don't care about obj.hasOwnProperty(key) con obj created from json
        if (key === 'title') {
            continue;
        }
        node.setAttribute(key, obj[key]);
    }


    var style = {};
    style[mxConstants.STYLE_SHAPE] = mxConstants.SHAPE_RECTANGLE;
    style[mxConstants.STYLE_PERIMETER] = mxPerimeter.RectanglePerimeter;
    style[mxConstants.STYLE_ROUNDED] = true;
    style[mxConstants.STYLE_FILLCOLOR] = 'red';
    graph.getStylesheet().putCellStyle('custom', style);

    //console.log('node', node);

    //var newCell =
    //place new cell
    this.parent = graph.insertVertex(parent, null, node, globalUsersCellX, globalUsersCellY, 80, 30, 'custom');
    //this.globalUsersCellX += 40;
    //this.globalUsersCellY += 40;
}


/**
 * Load cells from provided url
 * url - string
 * return void
 */
EqualAttrs.prototype.getCellsByURL = function(url){

    var _this = this;

    var onload = function(req){
        try{
            var responseData = JSON.parse(req.getText());

            if (responseData.rights !== undefined){
                _this.setRights(responseData.rights);
            }

            if (responseData.palettes !== undefined){
                _this.removePalletsByRights(responseData.palettes);
            }

            if (responseData.data !== undefined){
                responseData.data.forEach(function(el){
                    _this.createCellFromUserObject(el);
                })
            }
        } catch (e){
            console.log('Error while parsing JSON ',e.stack);
        }
    };

    var onerror = function(req){
          mxUtils.alert('Error while getting diagram from server');
    };

    new mxXmlRequest(url, 'key=value').send(onload, onerror);

};

//TODO Move to separate block
/**
 * enable/disable manu elements by rights
 */
EqualAttrs.prototype.setRights = function(rights){

    if (rights === undefined){
        return true;
    }

    var _this = this;

    var names = ['arrange','view','file','edit','extras','help'];

    //set enable/disable menus
    names.forEach(function(el){
        _this.editorUi.menus.get(el).setEnabled(rights.indexOf(el)>-1);
    })

    //remove paletes
    //_this.editorUi.sidebar.palettes

};

/**
 * remove pallets that don't allow to user
 */
EqualAttrs.prototype.removePalletsByRights = function(palettes){

    if (palettes === undefined){
        return true;
    }

    var _this = this;
    var sidebar = _this.editorUi.sidebar;
    var pals = sidebar.palettes;

    //base palletes that don't be removed
    palettes.push('search');
    //var pals = ['arrange','view','file','edit','extras','help'];

    //set enable/disable menus
    for(var key in pals) {
        if (palettes.indexOf(key) === -1){
            sidebar.removePalette(key)
        }
    }

    //_this.editorUi.sidebar.palettes.forEach(function(el){
    //    _this.editorUi.menus.get(el).setEnabled(rights.indexOf(el)>-1);
    //})

    //remove paletes
    //_this.editorUi.sidebar.palettes

};